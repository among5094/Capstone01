package com.example.withpet_login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;

import com.google.android.material.bottomnavigation.BottomNavigationView;


public class MainHome extends AppCompatActivity {


    /*
    //홈 탭 버튼
    ImageButton btnHome;
    ImageButton btnUser;
     */


    //bottom navigation view
    private FragmentManager fragmentManager;
    private MainMenuHomeFragment fragmentHome;
    private MainMenuProfileFragment fragmentProfile;
    private MainMenuPostFragment fragmentPost;
    private ImagViewToggle imageViewToggle;

    Button menuBtn;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_home);

        // ImagViewToggle 객체를 생성할 때 MainActivity의 Context를 전달합니다.
        imageViewToggle = new ImagViewToggle(this);

        ImageView favImg = findViewById(R.id.main_home_favorite_imageview);
        ImageView favImg2 = findViewById(R.id.main_home_favorite_imageview2);
        // 좋아요 버튼

        favImg.setOnClickListener(imageViewToggle);
        favImg2.setOnClickListener(imageViewToggle);

        // 게시글 메뉴 버튼
        menuBtn = (Button) findViewById(R.id.post_menuBtn);
        registerForContextMenu(menuBtn);




        //bottom navigation view
        fragmentManager = getSupportFragmentManager();
        fragmentHome = new MainMenuHomeFragment();
        fragmentProfile = new MainMenuProfileFragment();
        fragmentPost = new MainMenuPostFragment();

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomnavigationview_home);
        bottomNavigationView.setOnItemSelectedListener(new ItemSelectedListener());


        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.tab_layout, fragmentHome).commitAllowingStateLoss();

        
        //bottom navigation view 페이지 이동
        bottomNavigationView.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                if (item.getItemId() == R.id.navigation_home) {
                    return true;
                } else if(item.getItemId() == R.id.navigation_post) {
                    intent = new Intent(getApplicationContext(), MainPost.class);
                    startActivity(intent);
                    return true;
                } else if (item.getItemId() == R.id.navigation_profile) {
                        intent = new Intent(getApplicationContext(), userprofile.class);
                        startActivity(intent);
                        return true;
                    } else {
                        return false;
                    }
                }
        });


    }


    protected void onResume() {
        super.onResume();
        // Fragment가 다시 화면에 나타날 때 이미지뷰의 상태를 복원합니다.
        ImageView favImg = findViewById(R.id.main_home_favorite_imageview);
        ImageView favImg2 = findViewById(R.id.main_home_favorite_imageview2);
        imageViewToggle.restoreImageState(favImg);
        imageViewToggle.restoreImageState(favImg2);
    }


    //bottom navigation view ItemSelectedListener()
    class ItemSelectedListener implements BottomNavigationView.OnItemSelectedListener {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            FragmentTransaction transaction = fragmentManager.beginTransaction();

            if (menuItem.getItemId() == R.id.navigation_home) {
                transaction.replace(R.id.tab_layout, fragmentHome).commitAllowingStateLoss();
            }else if(menuItem.getItemId() == R.id.navigation_post) {
                transaction.replace(R.id.tab_layout, fragmentPost).commitAllowingStateLoss();
            }
            else if (menuItem.getItemId() == R.id.navigation_profile) {
                transaction.replace(R.id.tab_layout, fragmentProfile).commitAllowingStateLoss();
            }

            return true;
        }
    }

    class ImagViewToggle implements View.OnClickListener { // 좋아요 버튼 토글 클래스
        private int defaultImageResource = R.drawable.favorite;
        private int toggledImageResource = R.drawable.favorite_black;
        private SharedPreferences sharedPreferences;


        /* public void ImageViewToggle(int defaultImageResource, int toggledImageResource) {
            this.defaultImageResource = defaultImageResource;
            this.toggledImageResource = toggledImageResource;
        }
        */
        // 생성자에서 Context를 받아와 SharedPreferences를 초기화합니다.


        // 싱글톤 패턴을 사용하여 단일 인스턴스를 반환합니다.
        public ImagViewToggle(Context context) {
            sharedPreferences = context.getSharedPreferences("ImageViewState", Context.MODE_PRIVATE);
        }



        @Override
        public void onClick(View view) {
            ImageView imageView = (ImageView) view;

            // 현재 이미지의 리소스 아이디를 가져옴
            Integer currentImageResource = (Integer) imageView.getTag();

            if (currentImageResource == null || currentImageResource == defaultImageResource) {
                imageView.setImageResource(toggledImageResource);
                imageView.setTag(toggledImageResource);
                saveImageState(imageView.getId(), true); // 각 이미지뷰의 ID를 키로 사용하여 상태 저장
            } else {
                // 좋아요가 눌려있지 않을 때
                imageView.setImageResource(defaultImageResource);
                imageView.setTag(defaultImageResource);
                saveImageState(imageView.getId(), false); // 각 이미지뷰의 ID를 키로 사용하여 상태 저장
            }
        }

        // 각 이미지뷰의 상태를 저장하는 코드
        private void saveImageState(int imageViewId, boolean isToggled) {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(String.valueOf(imageViewId), isToggled);
            editor.apply();
        }

        // 저장된 각 이미지뷰의 상태를 복원하는 코드
        public void restoreImageState(ImageView imageView) {
            boolean isToggled = sharedPreferences.getBoolean(String.valueOf(imageView.getId()), false);
            if (isToggled) {
                imageView.setImageResource(toggledImageResource);
                imageView.setTag(toggledImageResource);
            } else {
                imageView.setImageResource(defaultImageResource);
                imageView.setTag(defaultImageResource);
            }
        }
    }


// 게시글 메뉴 버튼

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);

        MenuInflater mInflater = getMenuInflater();
        if (v == menuBtn) {
            mInflater.inflate(R.menu.post_menu, menu);
        }
    }



    // Override onContextItemSelected to handle context menu item clicks
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.delete){
            // 삭제 메뉴를 눌렀을 때 실행될 코드
            // 삭제 메뉴 선택 대화상자
            AlertDialog.Builder dlg = new AlertDialog.Builder(MainHome.this);
            dlg.setTitle("삭제");
            dlg.setMessage("삭제하시겠습니까?");
            dlg.setPositiveButton("확인", null); // 삭제 기능을 넣어 수정해야 함
            dlg.setNegativeButton("취소", null);
            dlg.show();
            return true;
        } else if(item.getItemId() == R.id.modify) {
            // 수정 메뉴를 눌렀을 때 실행될 코드
            // 수정 메뉴 선택 대화상자
            AlertDialog.Builder dlg = new AlertDialog.Builder(MainHome.this);
            dlg.setMessage("수정하시겠습니까?");
            dlg.setPositiveButton("확인", null); // 수정 기능을 넣어 수정해야 함
            dlg.setNegativeButton("취소", null);
            dlg.show();
            return true;
        }
        return false;
    }
}