package com.example.withpet_login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;

public class create_account_two extends AppCompatActivity {

    //회원가입 반려견 정보 입력 버튼
    Button btnBackCreate2;
    Button btnNextCreate2;
    //회원가입 반려견 정보 입력 버튼 끝

    //캘린더 변수
    private DatePickerDialog datePickerDialog;
    private Button dateButton;
    //캘린더 변수 끝

    //반려견 종 기타
    TextView petSpeciesEtc;
    Spinner petSpeciesSpnr;
    //반려견 종 기타 끝

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account_two);

        //이전, 다음으로 버튼
        btnBackCreate2 = (Button) findViewById(R.id.btn_back);
        btnNextCreate2 = (Button) findViewById(R.id.btn_next);
        //이전, 다음으로 버튼 끝

        //캘린더 변수
        initDatePicker();
        dateButton = findViewById(R.id.datePickerButton);
        dateButton.setText(getTodaysDate());
        //캘린더 변수 끝

        //반려견 종 기타
        petSpeciesEtc = (TextView) findViewById(R.id.create_petspecies_etc);
        petSpeciesSpnr = (Spinner) findViewById(R.id.create_spinner_petspecies);
        //반려견 종 기타 끝

        //회원가입 반려견 정보 입력 이전으로 버튼 클릭 이벤트
        btnBackCreate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), create_account.class);
                startActivity(intent);
            }
        });

        //회원가입 반려견 입력 회원가입 완료 버튼 클릭 이벤트
        btnNextCreate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });


        //반려견 종 기타
        //선택 항목이 변경될 때마다 호출되는 리스너 설정
        petSpeciesSpnr.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                String selectedItem = parent.getItemAtPosition(position).toString();

                if (selectedItem.equals("직접입력")) {
                    petSpeciesEtc.setVisibility(View.VISIBLE);
                } else {
                    petSpeciesEtc.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        //반려견 종 기타 끝


    }

    //캘린더 입력
    private String getTodaysDate()
    {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        month = month + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return makeDateString(day, month, year);
    }

    private void initDatePicker()
    {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener()
        {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day)
            {
                month = month + 1;
                String date = makeDateString(day, month, year);
                dateButton.setText(date);
            }
        };

        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        int style = AlertDialog.THEME_HOLO_LIGHT;

        datePickerDialog = new DatePickerDialog(this, style, dateSetListener, year, month, day);
        //datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());

    }

    //생년월일 입력 후 표시 글자
    private String makeDateString(int day, int month, int year)
    {
        return year + "년 " + month + "월 " + day + "일";
    }

    public void openDatePicker(View view)
    {
        datePickerDialog.show();
    }

}