package com.example.withpet_login;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;


import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.IOException;


public class MainPost extends AppCompatActivity {



    //bottom navigation view
    private FragmentManager fragmentManager;
    private MainMenuHomeFragment fragmentHome;
    private MainMenuProfileFragment fragmentProfile;
    private MainMenuPostFragment fragmentPost;

    private static final int REQUEST_CODE = 1;
    private ImageView imageView;
    private ImageView imageView2;
    private ImageView imageView3;
    private ImageView imageView4;
    private ImageView imageView5;

    EditText editText;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        Button button = (Button) findViewById(R.id.imgup); // 사진 선택 버튼
        Button postBtn = (Button) findViewById(R.id.postup); // 게시글 올리기 버튼
        imageView = (ImageView) findViewById(R.id.petimg); // 선택한 사진
        imageView2 = (ImageView) findViewById(R.id.petimg2); // 선택한 사진
        imageView3 = (ImageView) findViewById(R.id.petimg3); // 선택한 사진
        imageView4 = (ImageView) findViewById(R.id.petimg4); // 선택한 사진
        imageView5 = (ImageView) findViewById(R.id.petimg5); // 선택한 사진
        editText = (EditText) findViewById(R.id.postEdit); // 작성한 게시글


        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, REQUEST_CODE);
            }
        });


        //bottom navigation view
        fragmentManager = getSupportFragmentManager();
        fragmentHome = new MainMenuHomeFragment();
        fragmentProfile = new MainMenuProfileFragment();
        fragmentPost = new MainMenuPostFragment();

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomnavigationview_post);
        bottomNavigationView.setOnItemSelectedListener(new ItemSelectedListener());


        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.tab_layout, fragmentPost).commitAllowingStateLoss();

        // 프로필 버튼을 선택 상태로 설정
        bottomNavigationView.setSelectedItemId(R.id.navigation_post);


        //bottom navigation view 페이지 이동
        bottomNavigationView.setOnItemSelectedListener(new BottomNavigationView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                if (item.getItemId() == R.id.navigation_home) {
                    intent = new Intent(getApplicationContext(), MainHome.class);
                    startActivity(intent);
                    return true;
                } else if(item.getItemId() == R.id.navigation_post) {
                    return true;
                } else if (item.getItemId() == R.id.navigation_profile) {
                    intent = new Intent(getApplicationContext(), userprofile.class);
                    startActivity(intent);
                    return true;
                } else {
                    return false;
                }
            }
        });


    }

    //bottom navigation view ItemSelectedListener()
    class ItemSelectedListener implements BottomNavigationView.OnItemSelectedListener {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            FragmentTransaction transaction = fragmentManager.beginTransaction();

            if (menuItem.getItemId() == R.id.navigation_home) {
                transaction.replace(R.id.tab_layout, fragmentHome).commitAllowingStateLoss();
            }else if(menuItem.getItemId() == R.id.navigation_post) {
                transaction.replace(R.id.tab_layout, fragmentPost).commitAllowingStateLoss();
            }
            else if (menuItem.getItemId() == R.id.navigation_profile) {
                transaction.replace(R.id.tab_layout, fragmentProfile).commitAllowingStateLoss();
            }

            return true;
        }
    }
    //버튼을 클릭하면 시작되는 함수
    @SuppressLint("ResourceType")
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        int resourceId = R.drawable.baseline_add_photo_alternate_24;

        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri photoUri = data.getData();
            Bitmap bitmap = null;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), photoUri);
            } catch (IOException e) {
                e.printStackTrace();
            }
            //이미지뷰에 이미지 불러오기
            if (bitmap != null) {

                if(imageView.getDrawable() == null) {
                    imageView.setImageBitmap(bitmap);
                    editText.setEnabled(true);
                }
                else if(imageView2.getDrawable() == null) {
                    imageView2.setImageBitmap(bitmap);
                }
                else if(imageView3.getDrawable() == null) {
                    imageView3.setImageBitmap(bitmap);
                }
                else if(imageView4.getDrawable() == null) {
                    imageView4.setImageBitmap(bitmap);
                }
                else if(imageView5.getDrawable() == null) {
                    imageView5.setImageBitmap(bitmap);
                }
                else {
                    Toast tMsg = Toast.makeText(MainPost.this, "사진을 전부 선택하였습니다.", Toast.LENGTH_SHORT);
                } // 적용 안됨

            }
        }
    }
}