package com.example.withpet_login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    //회원가입 버튼
    private Button btnCreateAccount;
    //로그인 버튼
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //회원가입 버튼
        btnCreateAccount = (Button) findViewById(R.id.btn_create_account);
        //로그인 버튼
        btnLogin = (Button) findViewById((R.id.btn_login)) ;

        //회원가입 버튼 클릭 이벤트
        btnCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), create_account.class);
                startActivity(intent);
            }
        });
        //로그인 버튼 클릭 이벤트(아이디 비밀번호 일치 미구현)
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainHome.class);
                startActivity(intent);
            }
        });
    }
}