
package com.example.withpet_login;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class create_account_two extends AppCompatActivity {

    // DB
    private FirebaseAuth mFirebaseAuth; // Firebase 인증
    private DatabaseReference mDatabaseRef; // 실시간 데이터 베이스

    //회원가입 반려견 정보 입력 버튼
    private Button btnBackCreate2;
    private Button btnNextCreate2;
    //회원가입 반려견 정보 입력 버튼 끝

    private EditText petName;
    private EditText petEtc;
    private RadioGroup petGender;
    private RadioButton selectedRadioButton;

    //캘린더 변수
    private TextView year, month, day;
    private CalendarView cal_view;
    private LinearLayout cal_layout;
    private Button cal_btn;
    int selectYear, selectMonth, selectDay;
    //캘린더 변수 끝

    //반려견 종 기타
    private TextView petSpeciesEtc;
    private Spinner petSpeciesSpnr;
    private EditText petSpeciesEdt;
    //반려견 종 기타 끝

    //각 에딧텍스트 조건 충족 확인
    boolean petnameisok, petbirthisok, petgenderisok, petspeciesisok, petetcisok;

    //모든 에딧텍스트 true인지 나타내는 변수
    boolean isok = false;

    //반려견 성별 변수
    private String create_Petgender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account_two);

        // 데이터베이스
        mFirebaseAuth = FirebaseAuth.getInstance();
        mDatabaseRef = FirebaseDatabase.getInstance("https://withpetfirebase-default-rtdb.firebaseio.com").getReference();

        //이전, 다음으로 버튼
        btnBackCreate2 = (Button) findViewById(R.id.btn_back);
        btnNextCreate2 = (Button) findViewById(R.id.btn_next);

        // 반려견 정보
        petName = (EditText) findViewById(R.id.create_petname);
        petEtc = (EditText) findViewById(R.id.create_etc);
        petGender = (RadioGroup) findViewById(R.id.create_petgender_radiogroup);
        petSpeciesEdt = (EditText) findViewById(R.id.create_petspecies_etc);

        //캘린더 변수
        cal_btn = (Button) findViewById(R.id.calbtn);
        year = (TextView) findViewById(R.id.biyear);
        month = (TextView) findViewById(R.id.bimonth);
        day = (TextView) findViewById(R.id.biday);
        cal_view = (CalendarView) findViewById(R.id.calendar_view);
        cal_layout = (LinearLayout) findViewById(R.id.calendarlayout);

        //반려견 종 기타
        petSpeciesEtc = (TextView) findViewById(R.id.create_petspecies_etc);
        petSpeciesSpnr = (Spinner) findViewById(R.id.create_spinner_petspecies);

        //날짜 텍스트를 누르면 캘린더가 보이게함
        year.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cal_layout.setVisibility(View.VISIBLE);
            }
        });
        month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cal_layout.setVisibility(View.VISIBLE);
            }
        });
        day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cal_layout.setVisibility(View.VISIBLE);
            }
        });
        // 캘린더뷰에서 누른 날짜를 값에 대입
        cal_view.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int day) {
                // 현재 날짜 구하기
                Calendar currentDate = Calendar.getInstance();
                int currentYear = currentDate.get(Calendar.YEAR);
                int currentMonth = currentDate.get(Calendar.MONTH) + 1;
                int currentDay = currentDate.get(Calendar.DAY_OF_MONTH);
                // 선택한 날짜와 비교
                if (selectYear < currentYear ||
                        (selectYear == currentYear && selectMonth < currentMonth) ||
                        (selectYear == currentYear && selectMonth == currentMonth && selectDay < currentDay)) {
                    // 선택한 날짜가 현재 날짜보다 과거일 경우
                    selectYear = year;
                    selectMonth = month + 1; //month는 0부터 시작하므로 1을 더해줌
                    selectDay = day;
                    petbirthisok = true;
                } else {
                    // 선택한 날짜가 현재 날짜보다 미래일 경우
                    Toast.makeText(create_account_two.this, "현재의 날짜보다 넘을 수 없습니다.", Toast.LENGTH_SHORT).show();
                    petbirthisok = false;
                }
            }
        });
        cal_btn.setOnClickListener(new View.OnClickListener() {
            // 확인 버튼을 누르면 텍스트뷰에 선택한 날짜가 표시됨
            @Override
            public void onClick(View view) {
                cal_layout.setVisibility(View.GONE);
                year.setText(Integer.toString(selectYear));
                month.setText(Integer.toString(selectMonth));
                day.setText(Integer.toString(selectDay));
            }
        });

        //캘린더가 열려있을때 날짜 설정 확인 버튼과 회원가입창의 이전으로와 확인 버튼이 헷갈려
        //캘린더가 focus의 상태일 때 버튼의 clickble을 false, visibility를 invisible로 변환
        //그렇지 않을때는 반대
        //작동 X
        //gpt : 이 코드가 작동하지 않는 이유는 CalendarView는 일반적으로 포커스를 받지 않기 때문입니다.
        cal_view.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    btnNextCreate2.setVisibility(View.INVISIBLE);
                    btnNextCreate2.setClickable(false);
                    btnBackCreate2.setVisibility(View.INVISIBLE);
                    btnBackCreate2.setClickable(false);
                } else {
                    btnNextCreate2.setVisibility(View.VISIBLE);
                    btnNextCreate2.setClickable(true);
                    btnBackCreate2.setVisibility(View.VISIBLE);
                    btnBackCreate2.setClickable(true);
                }
            }
        });

        //반려견 종 기타
        //선택 항목이 변경될 때마다 호출되는 리스너 설정
        petSpeciesSpnr.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {
                String selectedItem = parent.getItemAtPosition(position).toString();

                if (selectedItem.equals("직접입력")) {
                    petSpeciesEtc.setVisibility(View.VISIBLE);
                    //반려견 종 기타
                    petSpeciesEdt.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                        }

                        @Override
                        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                            if (!charSequence.toString().isEmpty()) {
                                petspeciesisok = true;
                            } else {
                                petspeciesisok = false;
                            }
                        }

                        @Override
                        public void afterTextChanged(Editable editable) {
                        }
                    });
                } else {
                    petSpeciesEtc.setVisibility(View.GONE);
                    petspeciesisok = true;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        //반려견 종 기타 끝

        //회원가입 반려견 정보 입력 이전으로 버튼 클릭 이벤트
        btnBackCreate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), create_account.class);
                startActivity(intent);
            }
        });

        //회원가입 반려견 입력 회원가입 완료 버튼 클릭 이벤트
        btnNextCreate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                // 모든 정보가 입력되었는지 확인
                if (petnameisok && petbirthisok && petgenderisok && petspeciesisok && petetcisok) {
                    // 사용자가 입력한 정보를 변수에 할당
                    // create_account -> create_account2 데이터 받아오기
                    // ex) strName = name으로 하면 Realtime Database로는 정보가 넘어가지 않는 오류
                    Intent intent_toss = getIntent();
                    String strName = intent_toss.getStringExtra("name");
                    String strNickname = intent_toss.getStringExtra("nickname");
                    String strId = intent_toss.getStringExtra("id");
                    String strPassword = intent_toss.getStringExtra("password");
                    String strPhonenum = intent_toss.getStringExtra("phonenum");
                    String strEmail = intent_toss.getStringExtra("email");
                    String strPetname = petName.getText().toString();
                    String strPetbirth = year.getText().toString() + "-" + month.getText().toString() + "-" + day.getText().toString();
                    String strPetgender = create_Petgender;
                    String strPetspecies = petSpeciesSpnr.getSelectedItem().toString();
                    String strPetetc = petEtc.getText().toString();

                    // 모든 정보가 입력되었으면(isok가 true이면) 확인 버튼 누를 시 회원가입 후 로그인으로 넘어감
                    // 회원가입 처리 시작
                    mFirebaseAuth.createUserWithEmailAndPassword(strEmail, strPassword).addOnCompleteListener(create_account_two.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // 회원가입이 성공한 경우에만 데이터베이스에 정보를 저장
                                FirebaseUser firebaseUser = mFirebaseAuth.getCurrentUser();

                                // 사용자 객체 생성
                                UserAccount account = new UserAccount();
                                account.setIdToken(firebaseUser.getUid());
                                account.setEmailId(firebaseUser.getEmail());
                                account.setPassword(strPassword);
                                account.setName(strName);
                                account.setUserId(strId);
                                account.setNickname(strNickname);
                                account.setPhoneNum(strPhonenum);
                                account.setProfileImgUrl(null);

                                // 반려견 객체 생성
                                Pet pet = new Pet();
                                pet.setName(strPetname);
                                pet.setBirth(strPetbirth);
                                pet.setSpecies(strPetspecies);
                                pet.setEtc(strPetetc);
                                pet.setGender(strPetgender);

                                // UserAccount에 반려동물 정보 추가
                                account.addPet(pet);


                                mDatabaseRef.child("UserAccount").child(firebaseUser.getUid()).setValue(account).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        // 데이터베이스에 성공적으로 저장됨
                                        Log.d(TAG, "Data saved successfully");
                                        Toast.makeText(create_account_two.this, "회원가입 성공", Toast.LENGTH_SHORT).show();
                                        startActivity(intent); // 로그인으로 넘어감
                                        finish(); // 현재 화면 종료
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // 데이터베이스 저장 실패
                                        Log.e(TAG, "Error saving data to Firebase Realtime Database", e);
                                    }
                                });
                            } else {
                                // 회원가입에 실패한 경우의 처리
                                Toast.makeText(create_account_two.this, "회원가입에 실패", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } else {
                    Toast.makeText(create_account_two.this, "모든 정보를 입력하세요", Toast.LENGTH_SHORT).show();
                }
            }
        });
        //회원가입 버튼 클릭 리스너 끝

        //모두 채워졌는지 확인
        //반려견 이름
        petName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().isEmpty()) {
                    petnameisok = true;
                } else {
                    petnameisok = false;
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        //반려견 성별
        petGender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                // 선택이 된 경우
                if (i != -1) {
                    selectedRadioButton = findViewById(i);
                    create_Petgender = selectedRadioButton.getText().toString();
                    petgenderisok = true;
                }
                // 선택이 되지 않은 경우
                else {
                    petgenderisok = false;
                }
            }
        });


        //반려견 기타사항
        petEtc.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!charSequence.toString().isEmpty()) {
                    petetcisok = true;
                } else {
                    petetcisok = false;
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

    }
}